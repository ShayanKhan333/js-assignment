//CHAPTER:ALERT
//Qno1
//alert("Error! please enter a valid password");
//Qno2
//alert("Welcom To JS Land.....\nHappy Coding!");
//Qno3
//alert("Welcome to JS Land");
//Qno4
//alert("Happy Coding!\nPrevent this page from creatind addional dialogs.");
//Qno5
//alert("Hello......i can run JS through my browser console")
//CHAPTER:VARIABLES FO SRRINGS
//Qno1
//var myname = "Shayan Khan";
//alert(myname);
//Qno2
//var myage="17 year old"
//alert(myage)
//Qno3
//var me="certified mobile developer";
//alert(me)
//Qno4
//var pizza="PIZZA\nPIZZ\nPIZ\nPI\nP"
//alert(pizza)
//Qno5
//var email="My email address is shayan.ayan111@gmail.com"
//alert(email)
//Qno6
//var bol="I am trying to learn from the book\nA Smater To Learn Java script"
//alert(bol);
//CHAPTER:VARIABLES AND NUMBER
//Qno1
//var age=17;
//alert(age)
//Qno2
//var yourage=18
//alert(yourage)
//CHAPTER:VARIABLE NAME:LEGAL OR ILLEGAL
//Qno1
//declare 3 variables in one statement
//Ans;var,let,const.
//Qno2:declare 5 legal & 5 illegal variable names in javascript
//LEGAL
//A variable name must only contain alphabets, digits, and underscore.
//A variable name must start with an alphabet or an underscore only. It cannot start with a digit.
//No whitespace is allowed within the variable name.
//A variable name must not be any reserved word or keyword.
//Or you can use dollar sgin in start.
//ILLEGAL
//Variable names can only start with any alphabet(upper / lower case) 
//or '_'(underscore).White space 
//is not allowed in variable names.Variable names 
//cannot start with a numeric.
//The variable name must not have special characters like!
//Display this in your browser
//a)A heading starting"Rules for naming JS variable"
//b)a variable name can only contain alphabets,number,characters and underscore.
//c)variable must begin with a letter or the underscore character.
//d)variable names are case sensitive
//e)Variable name should not be js Keyword. 
//CHAPTER:MATH EXPRESSIONS
//Qno1
//var a=3
//var b=5
//var add= a+b
//console.log(add)
//var a=3
//var b=5
//var sub=a-b
//console.log(sub)
//var a=3
//var b=5
//var multi=a*b
//console.log(multi)
//var a=3
//var b=5
//var div=a/b
//console.log(div)
//Qno2
//Do the following using JS Mathematical Expressions a. Declare a variable.
//var x = 10;
//var a = x + 5; // add 5, result is 15
//var b = x - 5; // subtract 5, result is 5
//var c = x * 2; // multiply by 2, result is 20
//var d = x / 4; // divide by 4, result is 2.5
//var e = x % 3; // divide by 3 & return remainder, result is 1
//4. Cost of one movie ticket is 600 PKR. Write a script to 
//store
//ticket price in a variable & calculate the cost of buying 5 
//tickets
//var a =600
//var b=5
//var multi=a*b
//console.log(multi)




































